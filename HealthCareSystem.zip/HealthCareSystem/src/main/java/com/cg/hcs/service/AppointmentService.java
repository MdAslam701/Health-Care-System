package com.cg.hcs.service;

import java.util.List;

import com.cg.hcs.dao.AppointmentDao;
import com.cg.hcs.dao.IAppointmentDao;
import com.cg.hcs.dto.Appointment;
import com.cg.hcs.exception.HCSExceptions;

public class AppointmentService implements IAppointmentService {
	IAppointmentDao dao = new AppointmentDao();

	@Override
	public List<Appointment> veiwAppointment() throws HCSExceptions {
		return dao.veiwAppointment();
	}

	@Override
	public void updateAppointent(int id, String name) throws HCSExceptions {
		dao.updateAppointment(id, name);

	}

	@Override
	public void deleteAppointment(int id) throws HCSExceptions {
		dao.deleteAppointment(id);

	}

}

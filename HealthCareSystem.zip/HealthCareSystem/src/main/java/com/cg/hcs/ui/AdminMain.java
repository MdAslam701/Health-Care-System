package com.cg.hcs.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.hcs.dto.Person;
import com.cg.hcs.exception.HCSExceptions;
import com.cg.hcs.service.AdminService;
import com.cg.hcs.service.IAdminService;

public class AdminMain {
	private Logger logger = Logger.getLogger(AdminMain.class);

	@SuppressWarnings("resource")
	public void adminLogIn() throws HCSExceptions {
		
		IAdminService adminService = new AdminService();
		Scanner scanner = null;
		System.out.println("Welcome to Admin Page");
		boolean check1 = false;
		do {
		scanner = new Scanner(System.in);
		System.out.println("Enter Your UserId");
		int id = scanner.nextInt();
		//scanner.nextLine();
		System.out.println("Enter Your Password");
		String pass = scanner.next();
		//scanner.nextLine();
		Person person = adminService.getAdminObj(id);

		
			if (id == person.getUserId() && pass.equals(person.getPassword())) {
				check1 = true;
				System.out.println(" LogIn Successfull ");
				System.out.println("-----------------------------------------");
				System.out.println(" Welcome To Admin Page ");
				System.out.println("-----------------------------------------");

				boolean checkFlag = false;
				while(true) {
					do {
						try {

							System.out.println(" Press 1 To Add Diagnostic Center");
							System.out.println(" Press 2 To Delete Diagnostic Center");
							System.out.println(" Press 3 To Add Test");
							System.out.println(" Press 4 To Delete Test ");
							System.out.println(" Press 5 To View Appointments");
							System.out.println(" Press 6 To Accept/Reject Appointment");
							System.out.println(" Press 7 To Delete the Appointment");
							System.out.println(" Press 8 To Update Centre");
							System.out.println(" Press 9 To Exit");
							System.out.println("-----------------------------------------");
							

							DiagnosticCentreMain centreMain = new DiagnosticCentreMain();
							TestMain testMain = new TestMain();
							AppointmentMain appointmentMain = new AppointmentMain();
							System.out.println(" Enter Your Choice ");
							scanner.nextLine();
							int choice = scanner.nextInt();
							checkFlag = true;

							switch (choice) {
							case 1:
								
								centreMain.addCentre();
								break;

							case 2:
								centreMain.removeCentre();
								break;
								
							case 3:
								testMain.addTest();
								break;
								
							case 4:
								testMain.deleteTest();
								break;
								
							case 5:
								appointmentMain.viewAppointment();
								break;
								
							case 6:
								appointmentMain.updateAppointment();
								break;
								
							case 7:
								appointmentMain.deleteAppoinment();
								break;

							case 8:
								centreMain.updateCentre();
								break;
								
							case 9:
								System.exit(0);
								break;

							default:
								System.err.println(" The Range Is From 1-9 ");
								System.err.println(" Please Enter The Valid Choice ");
								checkFlag = false;
							}
						} catch (InputMismatchException e) {
							System.err.println(" Only Numbers Are Allowed ");
							checkFlag = false;
						}

					} while (!checkFlag);
				}
			} else {
				System.err.println("log in failed");
				check1 = false;
			}
		} while (!check1);
	}
}

package com.cg.hcs.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.hcs.dto.Appointment;
import com.cg.hcs.exception.HCSExceptions;
import com.cg.hcs.service.AppointmentService;
import com.cg.hcs.service.IAppointmentService;

public class AppointmentMain {
	IAppointmentService appointmentService = new AppointmentService();
	Scanner scanner = null;
	public void viewAppointment() {
		

		List<Appointment> app = null;
		try {
			app = appointmentService.veiwAppointment();
		} catch (HCSExceptions e) {
			System.err.println(e.getMessage());
		}
		for (Appointment appointment : app) {
			System.out.println("-------------------------------------------------------");
			System.out.println("Appointmnet id --> " + appointment.getAppointmentId());
			System.out.println("user id --> " + appointment.getUserId());
			System.out.println("centre id --> " + appointment.getCentre().getCentreId());
			System.out.println("Appointmnet status --> " + appointment.getIsApproved());
			System.out.println("Appointmnet date --> " + appointment.getDate());
			System.out.println("centre Address --> " + appointment.getCentre().getCentreAddress());
			System.out.println("centre name --> " + appointment.getCentre().getCentreName());
			System.out.println("centre phone --> " + appointment.getCentre().getPhoneNo());
			System.out.println("-------------------------------------------------------");
		}

	}

	public void updateAppointment() {
		 scanner = new Scanner(System.in);
		boolean flag = false;

		int id = 0;

		do {
			try {
				System.out.println("Enter the Appointment id");
				scanner.next();
				id = scanner.nextInt();

				flag = true;
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("Only number Allowed");
			}
		} while (!flag);

		boolean flag1 = false;
		do {
			try {
				System.out.println(" Press 1 to Accept\t2 to reject");
				scanner.next();
				int choice = scanner.nextInt();
				flag1 = true;
				switch (choice) {
				case 1:
					String name = "Accepted";
					try {
						appointmentService.updateAppointent(id, name);
						System.out.println("Appected");
					} catch (HCSExceptions e) {
						System.err.println(e.getMessage());
					}
					break;

				case 2:
					String name1 = "Rejected";
					try {
						appointmentService.updateAppointent(id, name1);
						System.out.println("Rejected");
					} catch (HCSExceptions e) {
						System.err.println(e.getMessage());
					}
					break;

				default:
					System.err.println("choose either 1 or 2");
					flag1 = false;

				}
			} catch (InputMismatchException e) {
				flag1 = false;
				System.err.println("Only number Allowed");
			}
		} while (!flag1);

	}
	
	public void deleteAppoinment() {
		 scanner = new Scanner(System.in);
		
		boolean flag = false;

		int id = 0;

		do {
			try {
				System.out.println("Enter the Appointment id");
				scanner.next();
				id = scanner.nextInt();

				flag = true;
			} catch (InputMismatchException e) {
				flag = false;
				System.err.println("Only number Allowed");
			}
		} while (!flag);
		
		try {
			appointmentService.deleteAppointment(id);
		} catch (HCSExceptions e) {
			System.err.println(e.getMessage());
		}
		
	}

}

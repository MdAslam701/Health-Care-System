package com.cg.hcs.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.hcs.dao.IAdminDao;
import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.dto.Person;
import com.cg.hcs.dto.Test;
import com.cg.hcs.exception.HCSExceptions;
import com.cg.hcs.service.AdminService;
import com.cg.hcs.service.DiagnosticService;
import com.cg.hcs.service.IAdminService;
import com.cg.hcs.service.IDiagnosticService;
import com.cg.hcs.validation.IValidation;
import com.cg.hcs.validation.Validation;

public class DiagnosticCentreMain {
	private Logger logger = Logger.getLogger(DiagnosticCentreMain.class);
	Scanner scanner = new Scanner(System.in);
	IValidation iValidation = new Validation();
	IDiagnosticService centerService = new DiagnosticService();
	public void addCentre() {
		Scanner sc = null;

		DiagnosticCentre centre = new DiagnosticCentre();

		try {
			// if (checkCentre()) {
			boolean nameFlag = false;
			do {
				System.out.println(" Enter Centre Name ");
				//sc = new Scanner(System.in);
				String name = "";
				name = scanner.nextLine();

				try {
					iValidation.validateName(name);
					centre.setCentreName(name);
					nameFlag = true;
				} catch (HCSExceptions e) {
					nameFlag = false;
					System.err.println(e.getMessage());
				}
			} while (!nameFlag);

			boolean addressFlag = false;

			do {
				String address = "";

				//sc = new Scanner(System.in);
				System.out.println(" Enter Centre Address");
				address = scanner.nextLine();
				try {
					iValidation.validateAdress(address);
					centre.setCentreAddress(address);
					addressFlag = true;

				} catch (HCSExceptions e) {
					addressFlag = false;
					System.err.println(e.getMessage());
					// e.printStackTrace();
				}

			} while (!addressFlag);

			boolean testFlg = false;

			do {
				String test = "";
				int choice = 0;
				//sc = new Scanner(System.in);
				System.out.println("Enter the number to add test");
				try {
					scanner.next();
					choice = scanner.nextInt();
					testFlg = true;
				} catch (InputMismatchException e) {
					System.err.println("Only Number Please");
					testFlg = false;
				}
				scanner.nextLine();
				List<Test> tests = new ArrayList<Test>();
				Test test2 = null;
				try {
					for (int i = 1; i <= choice; i++) {
						System.out.println(" Enter" + i + "Test Name ");
						test = scanner.nextLine();
						iValidation.validateName(test);
						test2 = new Test();
						test2.setTestName(test);
						tests.add(test2);
						testFlg = true;
						test2.setCentre(centre);
					}

					centre.setListOfTest(tests);

				} catch (HCSExceptions e) {
					testFlg = false;
					System.err.println(e.getMessage());
					// e.printStackTrace();
				}

			} while (!testFlg);

			boolean pinFlag = false;

			do {
				long pinNo = 0l;
				String pinNo1 = "";
				//sc = new Scanner(System.in);

				System.out.println(" Enter the pincode");
				try {
					pinNo1 = scanner.next();
					if (iValidation.validatePinNo(pinNo1)) {
						pinNo = Long.parseLong(pinNo1);
						centre.setPinCode(pinNo);
						pinFlag = true;
					}
				} catch (HCSExceptions e) {
					System.err.println(e.getMessage());
					pinFlag = false;
				}
			} while (!pinFlag);

			boolean numberFlag1 = false;

			do {
				long number = 0l;
				String number1 = "";
				//sc = new Scanner(System.in);
				try {

					System.out.println(" Enter the Phone Number");
					number1 = scanner.nextLine();
					if (iValidation.validatePhoneNo(number1)) {
						number = Long.parseLong(number1);
						centre.setPhoneNo(number);
						numberFlag1 = true;
					}

				} catch (InputMismatchException e) {
					System.err.println(" Only Numbers Are Allowed ");
					numberFlag1 = false;
				} catch (NumberFormatException e) {
					System.err.println(" Only Numbers Are Allowed ");
					numberFlag1 = false;
				} catch (HCSExceptions e) {
					System.err.println(" Length must be minimum 10 number and Only numbers");
					numberFlag1 = false;
				}

			} while (!numberFlag1);

			try {
				if (centerService.addCenter(centre)) {
					System.out.println("-------------------");
					System.out.println(" Added Successfull ");
					System.out.println("-------------------");
				} else {
					System.out.println("-------------------");
					System.err.println(" Adding Faild ");
					System.out.println("-------------------");
				}
			} catch (HCSExceptions e) {
				System.err.println(e.getMessage());
			}
//			} else {
//				logger.error("Error");
//			}
		} catch (NumberFormatException e) {
			System.out.println("-------------------");
			System.err.println("Adding Failed");
			System.out.println("-------------------");
		}
	}

	public void removeCentre() {
		boolean flag = false;

		int id = 0;
		do {
			try {
				System.out.println("Enter the Centre Id");
				//Scanner scanner = new Scanner(System.in);
				scanner.next();
				id = scanner.nextInt();
				flag = true;
			} catch (InputMismatchException e) {
				System.err.println("Only number allowed");
				flag = false;
			}
		} while (!flag);

		IDiagnosticService diagnosticService = new DiagnosticService();

		try {
			diagnosticService.removeCentre(id);
			System.out.println("-------------------");
			System.out.println("Removed");
			System.out.println("-------------------");

		} catch (HCSExceptions e) {
			System.err.println(e.getMessage());

		}

	}

	public void updateCentre() {
	
		
		boolean flag = false;
		int id = 0;
		do {
			try {
				System.out.println("Enter the Centre Id");
				
				scanner.next();
				id = scanner.nextInt();
				flag = true;
			} catch (InputMismatchException e) {
				System.err.println("Only number allowed ");
				flag = false;
			}
		} while (!flag);
		
		boolean addressFlag = false;

		String address = "";
		do {

			//sc = new Scanner(System.in);
			System.out.println(" Enter Centre Address");
			scanner.nextLine();
			address = scanner.nextLine();
			try {
				iValidation.validateAdress(address);
				//centre.setCentreAddress(address);
				addressFlag = true;

			} catch (HCSExceptions e) {
				addressFlag = false;
				System.err.println(e.getMessage());
				// e.printStackTrace();
			}

		} while (!addressFlag);
		
		boolean pinFlag = false;

		long pinNo = 0l;
		do {
			String pinNo1 = "";
			//sc = new Scanner(System.in);

			System.out.println(" Enter the pincode");
			try {
				
				pinNo1 = scanner.next();
				if (iValidation.validatePinNo(pinNo1)) {
					pinNo = Long.parseLong(pinNo1);
					//centre.setPinCode(pinNo);
					pinFlag = true;
				}
			} catch (HCSExceptions e) {
				System.err.println(e.getMessage());
				pinFlag = false;
			}
		} while (!pinFlag);

		long number = 0l;
		boolean numberFlag1 = false;
		do {
			String number1 = "";
			//sc = new Scanner(System.in);
			try {

				System.out.println(" Enter the Phone Number");
				scanner.nextLine();
				number1 = scanner.nextLine();
				if (iValidation.validatePhoneNo(number1)) {
					number = Long.parseLong(number1);
					//centre.setPhoneNo(number);
					numberFlag1 = true;
				}

			} catch (InputMismatchException e) {
				System.err.println(" Only Numbers Are Allowed ");
				numberFlag1 = false;
			} catch (NumberFormatException e) {
				System.err.println(" Only Numbers Are Allowed ");
				numberFlag1 = false;
			} catch (HCSExceptions e) {
				System.err.println(" Length must be minimum 10 number and Only numbers");
				numberFlag1 = false;
			}

		} while (!numberFlag1);

		
		
		try {
			centerService.updateCentre(id, address,	pinNo, number);
			System.out.println("Updated");
		} catch (HCSExceptions e) {
			System.err.println("Update Failed");
			System.err.println(e.getMessage());
		}
	}
	
}
	

/*
 * public boolean checkCentre() { Scanner scanner = new Scanner(System.in);
 * boolean nameFlag = false; String name = ""; IValidation validation = new
 * Validation(); IDiagnosticService service = new DiagnosticService();
 * DiagnosticCentre centre = null;
 * 
 * do { try { System.out.println("Enter The centre name"); name =
 * scanner.nextLine(); validation.validateName(name); nameFlag = true; }catch
 * (HCSExceptions e) { System.err.println(e.getMessage()); nameFlag = false; } }
 * while (!nameFlag);
 * 
 * boolean noFlag = false; int id = 0; do { try {
 * System.out.println("Enter the user Id"); id = scanner.nextInt(); noFlag =
 * true; } catch (InputMismatchException e) {
 * System.err.println("Only number Allowed"); noFlag = false; } } while
 * (!noFlag);
 * 
 * 
 * 
 * try { centre = service.checkCentre(id, name); } catch (HCSExceptions e) {
 * System.out.println("no centre present"); }
 * 
 * 
 * 
 * if(id == centre.getPerson().getUserId() &&
 * name.equals(centre.getCentreName())) { return true; }else { return false; }
 * 
 * }
 */

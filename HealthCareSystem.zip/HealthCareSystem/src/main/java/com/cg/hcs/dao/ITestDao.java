package com.cg.hcs.dao;

import com.cg.hcs.dto.Test;
import com.cg.hcs.dto.Test1;
import com.cg.hcs.exception.HCSExceptions;

public interface ITestDao {
	public Test getTest(int centreId) throws HCSExceptions;

	public boolean addTest(String name, int id) throws HCSExceptions;
	
	public void removeTest(int id) throws HCSExceptions;
}

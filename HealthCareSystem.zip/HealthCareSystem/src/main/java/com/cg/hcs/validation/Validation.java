package com.cg.hcs.validation;

import java.util.regex.Pattern;

import com.cg.hcs.exception.HCSExceptions;

public class Validation implements IValidation {

	@Override
	public boolean validateName(String name) throws HCSExceptions {
		boolean nameFlag = false;
		String nameRegEx = "[A-Z]{1}[A-Za-z\\s]{4,29}";

		if (Pattern.matches(nameRegEx, name)) {
			nameFlag = true;
		} else {
			throw new HCSExceptions("First letter should be capital and length must be in the range of 5 to 30");
		}
		return nameFlag;
	}

	@Override
	public boolean validateAdress(String address) throws HCSExceptions {
		boolean nameFlag = false;
		String addressRegEx = "[A-Za-z\\s]{5,50}";//^[#.0-9a-zA-Z\\s,-]+$";

		if (Pattern.matches(addressRegEx, address)) {
			nameFlag = true;
		} else {
			throw new HCSExceptions("Address should contains 5 words");
		}
		return nameFlag;
	}

	@Override
	public boolean validatePhoneNo(String phone) throws HCSExceptions {
		boolean nameFlag = false;
		String phoneRegEx = "[0-9\\d]{10}";

		if (Pattern.matches(phoneRegEx, phone)) {
			nameFlag = true;
		} else {
			throw new HCSExceptions("Length must be minimum 10 number");
		}
		return nameFlag;

	}

	@Override
	public boolean validatePinNo(String pinNo) throws HCSExceptions {
		boolean nameFlag = false;
		String pinRegEx = "[0-9\\d]{5,8}";

		if (Pattern.matches(pinRegEx, pinNo)) {
			nameFlag = true;
		} else {
			throw new HCSExceptions("Length must consists aleast 5 values and only numbers");
		}
		return nameFlag;
	}

}

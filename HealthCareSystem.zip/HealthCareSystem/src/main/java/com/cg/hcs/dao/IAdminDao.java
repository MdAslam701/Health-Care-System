package com.cg.hcs.dao;

import com.cg.hcs.dto.Person;
import com.cg.hcs.exception.HCSExceptions;

public interface IAdminDao {
	
	public Person getAdminObj(int id) throws HCSExceptions;

}

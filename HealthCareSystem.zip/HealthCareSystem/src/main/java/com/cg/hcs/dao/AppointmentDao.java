package com.cg.hcs.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.Transient;
import javax.transaction.Transaction;

import com.cg.hcs.dto.Appointment;
import com.cg.hcs.exception.HCSExceptions;

public class AppointmentDao implements IAppointmentDao {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transcation = null;

	@Override
	public List<Appointment> veiwAppointment() throws HCSExceptions {

		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();

		System.out.println("in app Dao");

		// String Query = "select p from Appointment p ";

		Query q = manager.createQuery(QueryConstants.VIEWALL_APPOINTMENTS, Appointment.class);

		List<Appointment> appList = null;

		try {

			appList = q.getResultList();

		} catch (Exception e) {
			throw new HCSExceptions("No Appointments Present yet");
		} finally {
			factory.close();
			manager.close();
		}

		return appList;
	}

	@Override
	public void updateAppointment(int id, String name) throws HCSExceptions {

		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();

		Appointment appointment = null;

		appointment = manager.find(Appointment.class, id);

		if (appointment == null) {
			throw new HCSExceptions("No id Found");
		}

		appointment.setIsApproved(name);
		try {
			manager.getTransaction().begin();
			manager.persist(appointment);
			manager.getTransaction().commit();
		} catch (PersistenceException e) {
			manager.getTransaction().rollback();
			throw new HCSExceptions("Update Failed");
		} finally {
			manager.close();
			factory.close();
		}

	}

	@Override
	public void deleteAppointment(int id) throws HCSExceptions {
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();
		transcation = manager.getTransaction();
		Appointment appointment = null;

		try {
			appointment = manager.find(Appointment.class, id);
			transcation.begin();
			manager.remove(appointment);
			transcation.commit();

		} catch (IllegalArgumentException e) {
			transcation.rollback();
			throw new HCSExceptions("No Id Found");
		} finally {
			manager.close();
			factory.close();
		}

	}

}

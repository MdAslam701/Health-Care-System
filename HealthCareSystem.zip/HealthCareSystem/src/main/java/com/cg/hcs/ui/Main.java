package com.cg.hcs.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.hcs.exception.HCSExceptions;

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		PropertyConfigurator.configure("src/main/resource/log4j.properties");
		Scanner scanner = null;
		String reChoice = "";

		while(true) {
			// scanner = new Scanner(System.in);
			System.out.println("--------------------------------------------------");
			System.out.println("     Welcome to Health Care Management System ");
			
			int choice = 0;
			boolean choiceFlag = false;

			do {
				System.out.println("--------------------------------------------------");
				System.out.println(" Press 1 For Admin");
				System.out.println(" Press 2 For User");
				System.out.println(" Press 3 For Exit");
				System.out.println("--------------------------------------------------");

				scanner = new Scanner(System.in);
				System.out.println("select your choice:");

				try {
					choice = scanner.nextInt();
					//scanner.next();
					choiceFlag = true;

					switch (choice) {
					case 1:
						//System.out.println("Admin");
						AdminMain main = new AdminMain();
						boolean flag = false;
						do {
							try {
								main.adminLogIn();
								flag = true;
							} catch (HCSExceptions e) {
								System.err.println("log failed ");
								flag = false;
							}
						} while (!flag);

						break;

					case 2:
						System.out.println("User");
						break;

					case 3:
						System.out.println("Thank You!!!!!!!!!!!!11");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("Input should be in the range of 1-3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("Input should contain only digits");
				}
			} while (!choiceFlag);

			
			
			
		}

	}
}

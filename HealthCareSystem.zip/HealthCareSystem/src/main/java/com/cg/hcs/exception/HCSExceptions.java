package com.cg.hcs.exception;

public class HCSExceptions extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3262968500903335148L;

	public HCSExceptions(String message) {
		super(message);

	}
}

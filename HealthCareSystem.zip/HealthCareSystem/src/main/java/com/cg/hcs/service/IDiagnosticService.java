package com.cg.hcs.service;

import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.exception.HCSExceptions;

public interface IDiagnosticService {

	public DiagnosticCentre getCentre(int id) throws HCSExceptions;

	public boolean addCenter(DiagnosticCentre centre) throws HCSExceptions;
	
	public void removeCentre(int id) throws HCSExceptions;
	
	public void updateCentre(int id, String Adress, long pinNo, long phoneNumber) throws HCSExceptions;

//	public DiagnosticCentre checkCentre(int id, String name) throws HCSExceptions; 

}

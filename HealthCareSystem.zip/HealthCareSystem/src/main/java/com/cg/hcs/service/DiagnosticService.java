package com.cg.hcs.service;

import com.cg.hcs.dao.DiagnosticDao;
import com.cg.hcs.dao.IDiagonsticDao;
import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.exception.HCSExceptions;

public class DiagnosticService implements IDiagnosticService {
	IDiagonsticDao dao = new DiagnosticDao();

	@Override
	public boolean addCenter(DiagnosticCentre centre) throws HCSExceptions {
		boolean addFlag = false;
		if (dao.addCentre(centre)) {
			addFlag = true;
		}

		return addFlag;
	}

	@Override
	public void removeCentre(int id) throws HCSExceptions {
		dao.removeCentre(id);

	}

	@Override
	public DiagnosticCentre getCentre(int id) throws HCSExceptions {

		return dao.getCentre(id);
	}

	@Override
	public void updateCentre(int id, String Adress, long pinNo, long phoneNumber) throws HCSExceptions {
		dao.updateCentre(id, Adress, pinNo, phoneNumber);

	}
}

//	@Override
//	public DiagnosticCentre checkCentre(int id, String name) throws HCSExceptions {
//
//		return dao.checkCentre(id, name);
//	}

//	@SuppressWarnings("resource")
//	@Override
//	public  boolean checkCentre( ) {
//
//		IDiagonsticDao dao = new DiagnosticDao();
//		boolean checkFlag = false;
//
//		String checkName = "";
//
//		Scanner sc = null;
//
//		sc = new Scanner(System.in);
//
//		DiagnosticCentre centre = null;
//		System.out.println(" Enter Centre Name ");
//		checkName = sc.nextLine();
//		System.out.println("Enter the id");
//		int id = sc.nextInt();
//		try {
//			 centre = dao.getCentre(checkName,);
//			if (!centre.getCentreName().equals(checkName)) {
//				System.out.println("No Entry Found Matched Can Continue Adding");
//				
//				checkFlag = true;
//			} else {
//				System.err.println("Entry Found");
//				checkFlag = false;
//			}
//		} catch (HCSExceptions e) {
//			System.out.println("No Entry Found Can Continue Adding");
//			
//			checkFlag = true;
//		} catch (NullPointerException e) {
//			System.out.println("No Entry Found Can Continue Adding1");
//			
//			checkFlag = true;
//		}
//		return checkFlag;
//
//	}

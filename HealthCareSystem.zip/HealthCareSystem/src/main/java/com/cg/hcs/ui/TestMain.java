package com.cg.hcs.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.dto.Test;
import com.cg.hcs.exception.HCSExceptions;
import com.cg.hcs.service.DiagnosticService;
import com.cg.hcs.service.IDiagnosticService;
import com.cg.hcs.service.ITestService;
import com.cg.hcs.service.TestService;
import com.cg.hcs.validation.IValidation;
import com.cg.hcs.validation.Validation;

public class TestMain {
	Logger logger = Logger.getLogger(TestMain.class);
	Scanner scanner = new Scanner(System.in);

	public void addTest() {

		IValidation iValidation = new Validation();
		ITestService testService = new TestService();
		Test test = new Test();

		String name = "";
		// if (testService.checkTest()) {
		boolean nameFlag = false;
		do {
			System.out.println(" Enter Test Name ");
			//sc = new Scanner(System.in);

			name = scanner.nextLine();

			try {
				iValidation.validateName(name);
				// test.setTestName(name);
				nameFlag = true;
			} catch (HCSExceptions e) {
				nameFlag = false;
				System.err.println(e.getMessage());
			}
		} while (!nameFlag);

		int id = 0;

		boolean noFlag = false;
		do {
			try {
				System.out.println("Enter the centre id");
				scanner.next();
				id = scanner.nextInt();
				noFlag = true;
			} catch (Exception e) {
				System.err.println("Only numbers allowed");
				noFlag = false;
			}
		} while (!noFlag);

		try {
			if (testService.addTest(name, id)) {
				System.out.println(" Added Successfull ");
			}
		} catch (HCSExceptions e) {
			System.err.println(e.getMessage());
			System.err.println(" Adding Faild ");
		}
//		}else {
//			System.err.println("Test found");
//		}

	}

	public void deleteTest() {
		ITestService service = new TestService();
		boolean flag = false;

		int id = 0;
		do {
			try {
				System.out.println("Enter the Test Id");
				//Scanner scanner = new Scanner(System.in);
				id = scanner.nextInt();
				scanner.next();
				flag = true;
			} catch (InputMismatchException e) {
				System.err.println("Only number allowed ");
				flag = false;
			}
		} while (!flag);

		try {

			service.removeTest(id);
			System.out.println("Test Removed");

		} catch (HCSExceptions e) {
			System.err.println(e.getMessage());

		}

	}

}

//			boolean numberFalg = false;
//				
//			do {
//				try {
////					System.out.println("Enter Centre id");
////					int id = sc.nextInt();
////					IDiagnosticService diagnosticService = new DiagnosticService(); 
////					
////				DiagnosticCentre centre	 = diagnosticService.getCentre(id);
//				
//				//test.setCentre(centre);
////					DiagnosticCentre centre = new DiagnosticCentre();
////					centre.setCentreAddress("Harihara");
////					centre.setCentreId(45);//centre.setCentreName("Diaa");
//					//test.setCentre(centre);
//					numberFalg = true;
//				} catch (InputMismatchException e) {
//					System.err.println("only numbers allowed");
//					numberFalg = false;
//		} //catch (HCSExceptions e) {
////					System.err.println("No Entity Found");
////					numberFalg = false;
////				}
//			} while (!numberFalg);

//		} else {
//			logger.error("Error");
//		}

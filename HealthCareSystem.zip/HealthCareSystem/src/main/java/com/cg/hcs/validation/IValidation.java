package com.cg.hcs.validation;

import com.cg.hcs.exception.HCSExceptions;

public interface IValidation {
	
	public boolean validateName(String name) throws HCSExceptions;

	// public boolean emailIdValidate(String email) throws HCSExceptions;

	public boolean validateAdress(String address) throws HCSExceptions;

	public boolean validatePhoneNo(String phone) throws HCSExceptions;

	public boolean validatePinNo(String pinNo) throws HCSExceptions;


}

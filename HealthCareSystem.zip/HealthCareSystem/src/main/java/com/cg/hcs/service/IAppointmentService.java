package com.cg.hcs.service;

import java.util.List;

import com.cg.hcs.dto.Appointment;
import com.cg.hcs.exception.HCSExceptions;

public interface IAppointmentService {
	
	public List<Appointment> veiwAppointment() throws HCSExceptions;
	
	public void updateAppointent(int id, String name) throws HCSExceptions;
	
	public void deleteAppointment(int id) throws HCSExceptions;

}

package com.cg.hcs.service;

import com.cg.hcs.dao.ITestDao;
import com.cg.hcs.dao.TestDao;
import com.cg.hcs.exception.HCSExceptions;

public class TestService implements ITestService{
	ITestDao dao = new TestDao();

	@Override
	public boolean addTest(String name, int id) throws HCSExceptions {
		boolean addFlag = false;
		if (dao.addTest(name, id)) {
			addFlag = true;
		}

		return addFlag;
	}

	@Override
	public void removeTest(int id) throws HCSExceptions {
		dao.removeTest(id);
		
	}

}

//	@SuppressWarnings("resource")
//	@Override
//	public boolean checkTest() {
//		ITestDao testDao = new TestDao();
//		boolean checkFlag = false;
//
//		String checkTestName = "";
//
//		Scanner sc = null;
//
//		sc = new Scanner(System.in);
//
//		Test test = null;
//		System.out.println(" Enter Centre Id");
//		int id = sc.nextInt();
//		sc.nextLine();
//		System.out.println(" Enter Test Name ");
//		checkTestName = sc.nextLine();
//		try {
//			test = testDao.getTest(id);
//			 
//			if (!test.getTestName().equals(checkTestName ) && id == test.getCentre().getCentreId()) {
//				System.out.println("No Entry Found Matched Can Continue Adding");
//				
//				checkFlag = true;
//			} else {
//				System.err.println("Entry Found");
//				checkFlag = false;
//			}
//		} catch (HCSExceptions e) {
//			System.out.println("No Entry Found Can Continue Adding");
//			
//			checkFlag = true;
//		} catch (NullPointerException e) {
//			System.out.println("No Entry Found Can Continue Adding1");
//			
//			checkFlag = true;
//		}
//		return checkFlag;
//	}
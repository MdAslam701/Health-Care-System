package com.cg.hcs.service;

import com.cg.hcs.dto.Person;
import com.cg.hcs.exception.HCSExceptions;

public interface IAdminService {
	
	public Person getAdminObj(int id) throws HCSExceptions;

}

package com.cg.hcs.dao;

import java.util.List;

import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.dto.Test1;
import com.cg.hcs.exception.HCSExceptions;

public interface IDiagonsticDao {
	
	public DiagnosticCentre getCentre(int id) throws HCSExceptions;
	
	public boolean addCentre(DiagnosticCentre centre) throws HCSExceptions;
	
	public void removeCentre(int id) throws HCSExceptions;
	
	public void updateCentre(int id, String Adress, long pinNo, long phoneNumber) throws HCSExceptions;
	
	//public DiagnosticCentre checkCentre(int id, String name) throws HCSExceptions;


}

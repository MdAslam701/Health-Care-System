package com.cg.hcs.dao;

public interface QueryConstants {
	
	String VIEWALL_APPOINTMENTS = "select p from Appointment p";
	
	String GET_CENTRE_TEST =  "select centre from Test centre where centre.centreId = :centreId";

}

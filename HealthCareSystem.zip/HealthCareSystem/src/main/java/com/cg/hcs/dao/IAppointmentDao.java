package com.cg.hcs.dao;

import java.util.List;

import com.cg.hcs.dto.Appointment;
import com.cg.hcs.exception.HCSExceptions;

public interface IAppointmentDao {
	
	public List<Appointment> veiwAppointment() throws HCSExceptions;
	
	public void updateAppointment(int id, String name) throws HCSExceptions;
	
	public void deleteAppointment(int id) throws HCSExceptions;
}

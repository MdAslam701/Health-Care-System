package com.cg.hcs.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.dto.Test;
import com.cg.hcs.dto.Test1;
import com.cg.hcs.exception.HCSExceptions;

public class TestDao implements ITestDao {

	private Logger logger = Logger.getLogger(TestDao.class);

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public Test getTest(int centreId) throws HCSExceptions {

//		logger.info("in get product method id is: " + centreId);
//		factory = JpaUtility.getEntityManagerFactory();
//		manager = factory.createEntityManager();
//		Test test = null;
//
//		test = manager.find(Test.class, centreId);
//		logger.debug(test);
//
//		if (test == null) {
//			logger.error("no test present");
//			throw new HCSExceptions("No test present with the given id");
//		}
//
//		return test;

		logger.info("in getTest name is: " + centreId);
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();

		// Query query = manager.createQuery(QueryConstants.GET_CENTER);

		Test test = null;

		System.out.println("In Dia Dao");

		manager.find(DiagnosticCentre.class, centreId);

		// String query1 = "select centre from Test centre where centre.centreId =
		// :centreId";

		TypedQuery<Test> query = manager.createQuery(QueryConstants.GET_CENTRE_TEST, Test.class);

		query.setParameter("centreId", centreId);
		try {
			test = query.getSingleResult();

		} catch (PersistenceException e) {
			System.out.println("No Entry Found");
		} finally {
			factory.close();
			manager.close();
		}

		return test;

	}

	@Override
	public boolean addTest(String name, int id) throws HCSExceptions {

		boolean addFlag = false;
		System.out.println("in Dia Dao");
		DiagnosticCentre centre = null;
		logger.info("in add test method");
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

		transaction.begin();
		try {
			centre = manager.find(DiagnosticCentre.class, id);

			Test test = new Test();

			List<Test> list = new ArrayList<Test>();

			test.setTestName(name);
			list.add(test);

			centre.setListOfTest(list);
			test.setCentre(centre);
			manager.persist(test);
			transaction.commit();

			addFlag = true;
		} catch (PersistenceException | NullPointerException e) {

			transaction.rollback();
			throw new HCSExceptions("No Centre Id Found");
		} finally {
			manager.close();
			factory.close();
		}
		return addFlag;

	}

	@Override
	public void removeTest(int id) throws HCSExceptions {
		System.out.println("in Test Dao remove");

		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		Test test = null;

		try {
			transaction.begin();
			test = manager.find(Test.class, id);
			logger.debug(test);
			manager.remove(test);
			transaction.commit();

		} catch (IllegalArgumentException e) {
			transaction.rollback();
			throw new HCSExceptions("No Test to Remove");

		} finally {
			factory.close();
			manager.close();
		}

	}

}

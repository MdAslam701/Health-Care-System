package com.cg.hcs.service;

import com.cg.hcs.dto.Test;
import com.cg.hcs.dto.Test1;
import com.cg.hcs.exception.HCSExceptions;

public interface ITestService {


	public boolean addTest(String name, int id) throws HCSExceptions;
	
	public void removeTest(int id) throws HCSExceptions;

	
	// public boolean checkTest();

}

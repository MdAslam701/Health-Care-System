package com.cg.hcs.service;

import com.cg.hcs.dao.AdminDao;
import com.cg.hcs.dao.IAdminDao;
import com.cg.hcs.dto.Person;
import com.cg.hcs.exception.HCSExceptions;

public class AdminService implements IAdminService {

	@Override
	public Person getAdminObj(int id) throws HCSExceptions {
		IAdminDao adminDao = new AdminDao();
		return adminDao.getAdminObj(id);
	}

}

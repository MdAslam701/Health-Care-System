package com.cg.hcs.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import org.apache.log4j.Logger;

import com.cg.hcs.dto.DiagnosticCentre;
import com.cg.hcs.exception.HCSExceptions;

public class DiagnosticDao implements IDiagonsticDao {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	private Logger logger = Logger.getLogger(DiagnosticDao.class);

	@Override
	public DiagnosticCentre getCentre(int id) throws HCSExceptions {
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();

		DiagnosticCentre centre = null;
		try {
			centre = manager.find(DiagnosticCentre.class, id);
		} catch (PersistenceException e) {
			System.out.println("in Get method");
		} finally {
			factory.close();
			manager.close();
		}
		return centre;
	}

	@Override
	public boolean addCentre(DiagnosticCentre centre) throws HCSExceptions {

		boolean addFlag = false;
		logger.info("in addCentre method");

		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

		transaction.begin();
		try {
			manager.persist(centre);
			transaction.commit();

			int centreId = centre.getCentreId();

			System.out.println("id generated " + centreId);
			addFlag = true;
		} catch (PersistenceException e) {
			logger.error(e.getMessage());

			transaction.rollback();
		} finally {
			manager.close();
			factory.close();
		}
		return addFlag;

	}

	@Override
	public void removeCentre(int id) throws HCSExceptions {

		logger.info("in removeCentre method");
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		DiagnosticCentre centre = null;

		try {
			transaction.begin();
			centre = manager.find(DiagnosticCentre.class, id);
			logger.debug(centre);
			manager.remove(centre);
			transaction.commit();

		} catch (IllegalArgumentException e) {
			transaction.rollback();
			throw new HCSExceptions("No Centre to Remove");

		} finally {
			factory.close();
			manager.close();
		}
	}

	@Override
	public void updateCentre(int id, String Adress, long pinNo, long phoneNumber) throws HCSExceptions {

		logger.info("in removeCentre method");
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		DiagnosticCentre centre = null;
		try {
			transaction.begin();
			centre = manager.find(DiagnosticCentre.class, id);
			centre.setCentreAddress(Adress);
			centre.setPhoneNo(phoneNumber);
			centre.setPinCode(pinNo);
			logger.debug(centre);
			manager.persist(centre);

			transaction.commit();

		} catch (IllegalArgumentException e) {
			transaction.rollback();
			throw new HCSExceptions("No Centre to update");

		} finally {
			factory.close();
			manager.close();
		}

	}
}

//	@Override
//	public DiagnosticCentre checkCentre(int id, String centreName) throws HCSExceptions {
//
//		logger.info("in getAdminObj id is: " + centreName);
//		factory = Persistence.createEntityManagerFactory("hcs_pu1");
//		manager = factory.createEntityManager();
//
//		DiagnosticCentre centre = null;
//		String q = "select * from centre_info where user_id = ? and centre_name = ?";
//
//		Query query = manager.createNativeQuery(q, DiagnosticCentre.class);
//
//		query.setParameter(1, id);
//		query.setParameter(2, centreName);
//
//		List<DiagnosticCentre> c = query.getResultList();
//
//		
//	//	System.out.println(centre.getCentreName());
//		String name = "";
//		for (DiagnosticCentre diagnosticCentre : c) {
//	 name = diagnosticCentre.getCentreAddress();
//		}
//
//		return centre;
//	}
//}

//		Person person = null;
//		
//		person = manager.find(Person.class, id);
//		
//		System.out.println(person.getUserId());
//		
//		 List<DiagnosticCentre> List = person.getCentreList();
//		List.
//		
//		return d;

//		
//		
//		
//		
//		
//
//		// Query query = manager.createQuery(QueryConstants.GET_CENTER);
//
//		DiagnosticCentre centre = null;
//		Person person = null;
//		//Test test = null;
//		
//		person = manager.find(Person.class, id);
//		
//		int id1 = person.getUserId();
//
//		System.out.println("In Dia Dao");
//		
//		String query1 = "select   from centre_info  where user_id =? ";
//
//		Query query = manager.createQuery(query1);
//
//		query.setParameter(1, id);
//		try {
//			
//			// centre= manager.find(DiagnosticCentre.class, 20);
//			//test = manager.find(Test.class, 20);
//			 
//			List<DiagnosticCentre> cList = query.getResultList();
//			System.out.println(centre.getCentreAddress());
//			System.out.println(centre.getCentreName());
//			System.out.println(centre.getPhoneNo());
//			//System.out.println(centre.getListOfTest());
//			List<Test> list = centre.getListOfTest();
//			for (Test test : list) {
//				System.out.println(test.getTestId());
//				System.out.println(test.getTestName());
//				//System.out.println(test.getCentre());
//			}
//			// System.out.println(centre);
//			 //logger.debug(centre);
//			
//
//		} catch (PersistenceException e) {
//			System.out.println("No Entry Found");
//		} finally {
//			factory.close();
//			manager.close();
//		}
//
//		return centre;

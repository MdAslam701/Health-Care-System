package com.cg.hcs.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
@Data
@Entity
@Table(name = "test_info")
public class Test1 {
	@Id
	@Column(name = "test_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int testId;
	@Column(name = "test_name")
	private String testName;
	//@Transient
	@Column(name = "centre_id")
	private int centreId;
	@Transient
	@Column(name = "appointment_id")
	private int appointmentId;

}

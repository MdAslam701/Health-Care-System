package com.cg.hcs.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.apache.log4j.Logger;

import com.cg.hcs.dto.Person;
import com.cg.hcs.exception.HCSExceptions;

public class AdminDao implements IAdminDao {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	private Logger logger = Logger.getLogger(AdminDao.class);

	@Override
	public Person getAdminObj(int id) throws HCSExceptions {
		logger.info("in getAdminObj id is: " + id);
		factory = Persistence.createEntityManagerFactory("hcs_pu1");
		manager = factory.createEntityManager();

		Person person = null;

		person = manager.find(Person.class, id);
		logger.debug(person);
		try {
			if (person == null) {
				logger.error(" No Id Present");
				throw new HCSExceptions("No Admin present with the given id/incorrect id or password");
			}
		} finally {
			factory.close();
			manager.close();
		}

		return person;
	}

}
